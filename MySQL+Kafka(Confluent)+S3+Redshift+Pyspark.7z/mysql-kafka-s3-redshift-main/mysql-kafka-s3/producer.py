from src.producer.kafka_writer import produce_data_to_kafka_topics
if __name__=="__main__":
    produce_data_to_kafka_topics()