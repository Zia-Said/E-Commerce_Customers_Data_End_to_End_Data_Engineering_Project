from src.consumer.kafka_reader import write_kafka_to_s3

if __name__=="__main__":
    write_kafka_to_s3()