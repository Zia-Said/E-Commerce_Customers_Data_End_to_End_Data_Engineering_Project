from dotenv import load_dotenv
print("Reading environment variable")
load_dotenv()